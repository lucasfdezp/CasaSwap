
import { CanActivateFn } from '@angular/router';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const authGuard:CanActivateFn=()=>{
  const auth=inject(AuthService);
  const router=inject(Router);
  if(!auth.isLogged()){router.navigate(['/']); return false;}
  return true;
};
