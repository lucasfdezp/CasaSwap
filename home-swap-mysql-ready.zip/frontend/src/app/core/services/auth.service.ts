
import { Injectable } from '@angular/core';

@Injectable({providedIn:'root'})
export class AuthService{
  tokenKey='token';
  setToken(t:string){localStorage.setItem(this.tokenKey,t);}
  getToken(){return localStorage.getItem(this.tokenKey);}
  isLogged(){return !!this.getToken();}
}
