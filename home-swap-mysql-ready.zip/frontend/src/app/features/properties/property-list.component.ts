
import { Component } from '@angular/core';

@Component({
  standalone:true,
  selector:'app-properties',
  template:`<h2>HomeSwap PRO funcionando 🚀</h2>`
})
export class PropertyListComponent{}
