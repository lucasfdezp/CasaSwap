
1. Instala Angular CLI:
npm install -g @angular/cli

2. Crear app:
ng new frontend --standalone

3. Copia src/app encima de tu proyecto
4. Ejecuta:
ng serve
