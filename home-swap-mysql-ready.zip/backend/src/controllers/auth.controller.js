
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

export const register = async (req,res)=>{
  const {email,password} = req.body;
  const hash = await bcrypt.hash(password,10);
  const user = await prisma.user.create({data:{email,password:hash}});
  res.json(user);
};

export const login = async (req,res)=>{
  const {email,password} = req.body;
  const user = await prisma.user.findUnique({where:{email}});
  if(!user) return res.sendStatus(401);
  const valid = await bcrypt.compare(password,user.password);
  if(!valid) return res.sendStatus(401);
  const token = jwt.sign({id:user.id},process.env.JWT_SECRET);
  res.json({token});
};
